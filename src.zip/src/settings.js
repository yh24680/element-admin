module.exports = {

  title: '菜鸟进阶后台系统',

  /**
   * @type {boolean} true | false
   * @description Whether fix the header
   */
  fixedHeader: false,

  /**
   * @type {boolean} true | false
   * @description Whether show the logo in sidebar
   *设置侧边栏上方的logo是否显示
   */
  sidebarLogo: true
}
