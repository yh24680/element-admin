<template>
  <div class="dashboard-container">
    <div class="dashboard-text">name: {{ name }}</div>
    <input
      ref="file"
      type="file"
      accept="image/jpg,image/gif,image/png,image/jpeg"
      @change="handleChange"
    />
    <img width="100%" :src="dialogImageUrl" alt="">
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import COS from 'cos-js-sdk-v5'
var cos = new COS({
  SecretId: 'AKIDb1JL8eutcDZeSzGGzRcXBYeU3LM8dsqW',
  SecretKey: 'SdXAXdS0IJ4ZonVw6zbwzmIXVCcldhV2'
})
console.log(cos)
export default {
  name: 'Dashboard',
  computed: {
    ...mapGetters([
      'name'
    ])
  },
  methods: {
    handleChange (e) {
      console.dir(e.target)
      cos.putObject({
        Bucket: 'lonely-1313062313', /* 必须 */
        Region: 'ap-shanghai', /* 存储桶所在地域，必须字段 */
        Key: 'yuxiansheng', /* 必须 */
        StorageClass: 'STANDARD',
        Body: e.target.files[0], // 上传文件对象
        onProgress: function (progressData) {
          console.log(JSON.stringify(progressData))
        }
      }, function (err, data) {
        console.log(err || data)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
